/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package repeticaofor;

/**
 *
 * @author Ederson
 */
public class RepeticaoFor {
    public static void main(String[] args) {
        // TODO code application logic here
        for (int c=0;c<=100;c+=10)
            System.out.println(c);
            
    }
    
}
