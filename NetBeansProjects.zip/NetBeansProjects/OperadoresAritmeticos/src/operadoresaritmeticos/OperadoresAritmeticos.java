/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package operadoresaritmeticos;

/**
 *
 * @author Ederson
 */
public class OperadoresAritmeticos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n1 = 3;
        int n2 = 5;
        float m = (n1 + n2)/2;
        System.out.println("A media é igual a " + m);
        
        int numero = 5;
        int numero1 = 5;
        numero++;
        numero1--;
        
        System.out.println(numero);
        System.out.println(numero1);
        System.out.println(5+ ++numero);
        
        /*int numero = 10;
        int valor = 4 + numero--;
        System.out.println(valor);
        Sustem.out.println(numero);
        */
        
        /*int x = 4;
        x += 2; // x = x + 2
        System.out.println(x);
        */ 
        
        /* flot v = 8.9;
        int ar = (int) Math.ceil(v); // ceil arredonda pra cima
        System.out.println(ar);
        int ar = (int) Math.floor(v); // ceil arredonda pra baixo
        System.out.println(ar);
        int ar = (int) Math.round(v); // ceil arredonda conforme a aritmetica
        System.out.println(ar);
        */
        
        /*double ale = Math.ramdom()
        int n = (int) (1 + ale * (100-1)); // randomiza de 1 a 100
        System.out.println(n);
        
        */
    }
     
}
